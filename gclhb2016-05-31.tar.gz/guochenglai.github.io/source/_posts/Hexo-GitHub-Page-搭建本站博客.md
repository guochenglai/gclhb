---
title: Hexo+GitHub Page 搭建本站博客
toc: true
mathjax: true
date: 2016-05-31 19:59:54
categories: 杂谈
tags:
- Hexo
- GitHub Page
- 搭建博客
description: 本站博客是基于Hexo和Maupassant搭建的，代码服务托管在GitHub Pages上。所有的代码均来自网络。感谢那些乐于奉献的大神将自己开发的工具分享到网络并让我们能够自由使用和传播。才使得我能在如此之小的时间成本和金钱成本之内完成自己的博客搭建。在之前我也层用Java编写过自己的博客，最后考虑到各种成本，还是切换到本文所提的方法。在我的第一篇博客中提到过，当我觉得我的博客已经开发完成之后，就公开我的博客的搭建方法，并开放源代码。今天终于付诸实现了。分享真是给人带来快乐的一件事情...
---
# 综述
# 本地博客搭建
# 配置maupassant样式
# 定制maupassant
# 部署到GitHub Pages