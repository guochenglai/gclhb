---
title: screen管理远程会话不被kill
toc: true
mathjax: true
date: 2016-06-07 20:06:00
categories: Linux常用技巧
tags: 
- Linux
- Linux常用技巧
description: 在我们的开发过程中经常需要 SSH 或者 telent 远程登录到 Linux 服务器。然后执行一些运行时间很长的任务。通常情况下我们都是为每一个这样的任务开一个远程终端窗口，因为他们执行的时间太长了。必须等待它执行完毕，在此期间可不能关掉窗口或者断开连接，否则这个任务就会被杀掉，一切半途而废了。最近终于找到了解决这个问题的神器-screen。
---
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;在我们用shell终端，执行一个命令的时候，我们所执行的任务都是这个shell终端的子进程。如果因为用户注销或者断网，shell终端会收到系统发来的HUP信号，当shell终端收到HUP信号之后，会关闭shell终端的子进程以及，shell终端本身性能。所以解决大任务不被kill的方法有两种：1 让shell进行忽略HUP信号 2让进程不属于shell终端子进程。下面将介绍着几种方法。
## nohub
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nohub的用途是让提交的命令忽略HUP信号，使用的时候只需要在我们的shell命令前面加入<font color=red>nohup</font>命令即可如下：
```
 nohup brew install mysql &
```
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;shell终端回显如下：
```
appending output to nohup.out
```
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;说明：这是一个安装MySQL的长任务，我们在shell命令前面加：nohub命令。然后执行任务的进程不再接受hup信号，即使shell终端被关闭，这个任务也可以继续执行。日志文件会输出到当前目录的nohup.out文件。
## 线程后台运行
**常见的理解误区:**
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;打开一个base终端，查看终端的信息如下：
![](http://7xutce.com1.z0.glb.clouddn.com/screen%2Fdemo_bash_01.png)
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;执行如下命令：
```
ping www.baidu.com &
```
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;查看我们任务的进程
![](http://7xutce.com1.z0.glb.clouddn.com/screen%2Fdemo_bash_02.png)
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;可以发现，ping命令进程的父进程ID是：78831，正好是我们打开的bash进程的ID，可见。我们的任务的进程还是bash进程的子进程，如果bash进程被kill，那么我们的进程还是会被杀掉。
**解决方案：**
```
(ping www.baidu.com &)
```
然后我们在查看进程的信息如下：
![](http://7xutce.com1.z0.glb.clouddn.com/screen%2Fdemo_bash_03.png)
发现我们任务的进程的父进程ID不再是bash进程，而是init进程。
## screen
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;screen执行命令的好处：
1 可以执行任意复杂的命令，还包括自己变成的函数，bohub不行。
2 工作环境和shell完全一样。
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;在使用screen的时候，可以类比vim，他们的各个方面都很类似。特别是刚使用screen的时候，有时候你甚至不知道自己是在shell环境中，还是在screen环境中。
常用screen技巧：
1 进入screen
 在shell终端输入如下的命令进入screen。
```
screen 
```
2 切换到screen命令窗口，类似vim的命令窗口：
```
ctrl + a
```
**scrren常见的命令如下：**
```
?	显示所有键绑定信息
w	显示所有窗口列表
C-a	切换到之前显示的窗口
c	创建一个新的运行shell的窗口并切换到该窗口
n	切换到下一个窗口
p	切换到前一个窗口(与C-a n相对)
0..9	切换到窗口0..9
a	发送 C-a到当前窗口
d	暂时断开screen会话
k	杀掉当前窗口
[	进入拷贝/回滚模式
```


使用pstree查看进程的进程树
```
pstree -H 9867
```