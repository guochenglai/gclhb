---
title: 个人简介
date: 2016-05-25 16:55:21
---
<table broder='0' width='500' style="margin-top:-160px">
     <tr hight='200'>
       <td width='300' align='left'>
            ![](/fancybox/me.jpg)
       </td>
       <td width='200' align='left'>
*姓&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;名*&nbsp;:&nbsp;郭承来
*工作经历*&nbsp;:&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2014-05 -- 至今  [去哪儿网](http://www.qunar.com/)
*简&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;介*&nbsp;:&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font size=2>主要研究编写Java程序，对Java多线程技术有着浓厚的兴趣。同时对围绕以Java为核心的，Spring，Mybatis，Mysql,Shell,Python等技术也有一些涉猎。</font>
*说&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;明*&nbsp;:&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font size=2>1 &nbsp;&nbsp; 本博客所有的404页面，都转发到了腾讯公益。所以如果你点击某个按钮跳转到了腾讯公益，说明本网站有些功能出现了问题。但是绝对不是广告。
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2 &nbsp;&nbsp; 为了节约开发成本，本站所有的评论功能都托管给了“多说”公司，默认评论会转发到QQ空间。如果不喜欢，记得把勾选去掉。</font>

       </td>
     </tr>
</table>