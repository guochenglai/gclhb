---
title: Java命令学习系列1——Jps
toc: true
mathjax: true
date: 2016-07-12 10:02:11
categories:
- Java
- Java命令工具
tags:
- Java
- jps
description:  
---
<code>jps</code>命令的作用是显示当前用户的Java进程。相当于Linux系统下的<code>ps aux | grep java</code>命令。但是jps并不是使用应用程序名称来查找JVM实例，而是查找当前用户的所有Java进程。

## 功能
jps（Java Virtual Machine Process Status Tool）是JDK1.5提供的用来显示<font color=red>当前用户</font>的所有Java进程的命令行工具，一般用于在Linux平台上查找我们需要分析的Java进程。<font color=red>
注意：
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1 本文所有的内容是以Linux为例！！！   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2 jps命令只能显示当前用户的Java进程
</font>   
## 实现原理
Java进程启动之后会在 <code>/tmp/</code>目录下生成一个：<code>hsperfdata_{user}</code>格式的文件夹。如下图所示：
![](http://7xutce.com1.z0.glb.clouddn.com/java%2Fjps%2F01_ls_tmp.png)
在这些文件夹之下有一些文件，这些文件的名字就是该文件夹对应的用户的Java程序。如下图所示：
![](http://7xutce.com1.z0.glb.clouddn.com/java%2Fjps%2F02_ls_hsprefdata.png)
可以看到 flume用户有一个Java进程（进程Id为3113），tomcat用户有一个Java进程（进程Id为12010）。
因此，列出当前用户的所有Java进程的方法就是遍历<code>/tmp</code>目录下的所有属于当前用户的文件而已。

## 使用方法
### jps参数详细说明
可以使用<code>jps -help</code>来查看jps命令所支持的所有选项：
![](http://7xutce.com1.z0.glb.clouddn.com/146960093888164.jpg?imageView2/0/format/jpg)

### jps -g 
**只显示进程的id**
![](http://7xutce.com1.z0.glb.clouddn.com/146960134250092.jpg?imageView2/0/format/jpg)
### jps -m 
**输出传递给main的参数**
![146960152463069.jpg](http://7xutce.com1.z0.glb.clouddn.com/146960152463069.jpg?imageView2/0/format/jpg)
### jps -l 
**输出应用程序的包名，主文件名，jar文件的完整路径（如果是jar）**
![146960169958866.jpg](http://7xutce.com1.z0.glb.clouddn.com/146960169958866.jpg?imageView2/0/format/jpg)
### jps -v 
**输出传递给jvm的参数**
![146960193542242.jpg](http://7xutce.com1.z0.glb.clouddn.com/146960193542242.jpg?imageView2/0/format/jpg)

