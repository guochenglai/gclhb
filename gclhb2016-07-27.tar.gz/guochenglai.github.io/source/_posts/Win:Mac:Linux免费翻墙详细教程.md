---
title: Win/Mac/Linux免费翻墙详细教程
toc: true
mathjax: true
date: 2016-07-09 14:32:12
categories: 杂谈
tags: 翻墙
description: 自从GFW问世以来，将整个天朝又慢慢地走向了改(bi)革(guan)开(suo)放(guo)的道路，作为一个有志青年，怎么可能不阅读外国的文献。所以就走上了翻墙之路，最近发现，亚马逊推出了一款云主机，可以免费用一年(换个账号和密码又可以用一年)，所以就诞生了如下的免费翻墙教程。试用于所有的操作系统平台。
---
# 概述
自从GFW问世以来，将整个天朝又慢慢地走向了改(bi)革(guan)开(suo)放(guo)的道路，作为一个有志青年，怎么可能不阅读外国的文献。所以就走上了翻墙之路，但是期间用过一些免费的服务，例如 ```红杏``` 但是最近随着浏览器翻墙被禁止之后。貌似走不通了，所以最后只剩下了一条道路，自己租用国外的服务器，然后建立VPN，代理到国外的网络。这个方法一直用到了现在，而且最近发现，亚马逊推出了一款云主机，可以免费用一年(换个账号和密码又可以用一年)，所以就诞生了如下的免费翻墙教程。适用于所有的操作系统平台，不同的操作系统只是如下的第三步不同(每个操作系统下载自己操作系统对应的客户端)
总体思路如下：
-  在亚马逊申请免费试用一年的云主机。(如果读者能够找到这样的云主机，按照下面的教程，理论上可以一直免费试用，不过如果要想好的用户体验可以去买一个国外的云主机，都挺便宜的，而且用户体验好)
-  在云主机上装一个ShadowSocket的server端程序，并进行配置
-  在本地下载一个ShadowSocket的客户端程序，填入Server端配置的账号即可免费翻墙。

# 注意事项
具体参见 [免费的午餐不好吃](http://bropaul.com/post/amazon-aws-in-practice)。
<font color=red>虽然服务器是免费的，但是是有条件的，不能超过流量和IO的上线，否则会自动收费（前面已经绑定了信用卡），所以请注意，不要使用本教程看视频，否则你会破产。日常一个人访问网页还是可以的。最好不要和别人共享。一年到期记得关机。</font>

# 详细教程
鉴于很多人都是小白，所以本文将列出第一部分提出的三个过程的详细教程。
## 亚马逊申请免费一年云主机
### 账号申请教程
申请云主机的地址: [amazon_aws](https://aws.amazon.com/cn/)
<font color=red>
1 打开上面超链接的官网界面如下：
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fvps_register_1.png)
2 如果有账号就直接登录，如果没有账号点击右上角的”注册“按钮进行注册，注册界面如下：
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fvps_register_2.png)
3 输入账号点击“登录”这里的登录即注册，出现如下界面：
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fvps_register_3.png)
4 点击”创建账户“，继续填写信息
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fvps_register_4.png)
5 点击”创建账户并继续“，填写你的信用卡信息如下：
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fvps_register_5.png)
6 点击”继续“会进行人机交互，确认你的电话
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fvps_register_6.png)
7 这时候会接到亚马逊官网的电话，并在电话中填入下图的验证码。
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fvps_register_7.png)
8 验证完成之后会出现如下的界面
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fvps_register_8.png)
9 点击“选择支持方案”出现如下的页面，选择“基本”
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fvps_register_9.png)
10 点击”继续“出现如下的页面。然后点击页面右上角的按钮”启动管理控制台“
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fvps_register_10.png)
</font>

### 创建主机教程

<font color=red>
1 进入如下的页面选择第一个: EC2，界面如下：
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fec2_create_1.png)
2 点击“创建组”出现如下的界面
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fec2_create_2.png)
3 点击启动示例，选择一个服务器的操作系统，我选择的是amzon自己的服务器操作系统，你也可以选择Ubuntu的或者RedHat的，这个取决于你的喜好，点击系统后面的“选择”按钮。
4 点击选择按钮之后，出现如下的选择CPU和内存的页面，可以直接选择亚马逊推荐的即可
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fec2_create_4.png)
5 点击“审核和启动”按钮
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fec2_create_5_1.png)
6 点击“启动创建密钥对”,在密钥对名称的地方输入"MyFirstKey.pem",如下图：
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fec2_create_6.png)
7 出现如下的界面表示成功
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fec2_create_7.png)
</font>

### 本地连接亚马逊云主机
我用的是Mac电脑，本文就以Mac电脑为示例，如果是windows用户参考亚马逊官方教程 [使用 PuTTY 从 Windows 连接到 Linux 实例](http://docs.aws.amazon.com/zh_cn/AWSEC2/latest/UserGuide/putty.html)

1 打开Mac的终端输入如下命令：
<code>sudo mv  ~/Downloads/MyFirstKey.pem ~/.ssh/</code>
2 修改文件的权限
<code>sudo chmod 400 ~/.ssh/MyFirstKey.pem</code>
3 登陆你的亚马逊服务器，换成你的IP，用户名都是固定的，注意IP是亚马逊给你提供的公有IP。Ubuntu的用户名貌似的"ubuntu"
<code>ssh -i ~/.ssh/MyFirstKey.pem ec2-user@52.XXX.XXX.XXX</code>

## 亚马逊云主机上配置ShadowSockert的Server端
这里已经登陆上了亚马逊的云主机，所以这些命令都是在云主机上执行的。
1 切换到root账号
<code>sudo su root</code>
2 安装python支持
如果是前面系统选择的是ubuntu执行：
<code>apt-get install python-pip</code>
如果前面主机系统选择的是亚马逊的请执行
<code>yum intsall python-pip</code>
3 安装shadowsocket服务器
<code>pip install shadowsocks</code>
<code>注意这里可能会报错说 pip命令找不到。解决方法是：
查看/usr/local/bin下面是否有pip文件，如果有则建立一个软连到/usr/bin目录，执行
ln -s /usr/local/bin/pip /usr/bin
</code>
4 配置shadowsocket
4.1 新建一个配置文件
<code>vi /etc/shadowsocks.json</code>
4.2文件内容如下：
<code>
{
    "server":"0.0.0.0",
    "server_port":8888,
    "local_address":"127.0.0.1",
    "local_port":1080,
    "password":"这里填入你想要填的密码",
    "timeout":300,
    "method":"aes-256-cfb",
    "fast_open":false
}
</code>
5 启动ShadowSocket，执行如下命令
<code>ssserver -c /etc/shadowsocks.json -d start</code>
如果报错请参考问题3的解决方案
<font color=red>
6 配置入站规则，如果不配置本地是不能通过shadowsocket连接的。
6.1 打开正在运行的实例，向右滚，找到“安全组”选择
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fconfig_security_1.png)
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fconfig_security_2.png)
6.2点击最后一个安全组选项
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fconfig_security_3.png)
6.3点击操作编辑入栈规则，注意端口，要与配置的server_port相同，这里是8888
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fconfig_security_4_1.png)
至此，服务器端就配置完了，客户端就可以连接了。
</font>
## 本地配置ShadowSocket的Client端
<font color=red>
我用的Mac,所以下面的mac电脑的配置，windows应该差不多。
1 下载shadowsocket，这个建议一定要去官网下载，[官网下载连接](https://shadowsocks.org/en/download/clients.html)
2 进行安装
3 配置
3.1 点击 “open server preferences”进入配置页面
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fclient_config_1.png)
3.2 添加左边的 "+"在右边填入的你的服务器信息 Address是服务器的IP，Password是服务器上你在配置文件中填入的密码，Remarks是一个别名，可填可不填
![](http://7xutce.com1.z0.glb.clouddn.com/vps%2Fclient_config_2.png)
<font>