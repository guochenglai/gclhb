---
title: Beyond-Compare-无限试用
toc: true
mathjax: true
date: 2016-06-12 20:51:03
categories:
- Mac常用技巧
- 软件破解
tags: 
- Mac常用技巧
- 软件破解
description:
---
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;前面一篇文章介绍了 ``` Beyond Comapre ``` 和其他工具的结合试用教程: [使用Beyond Compare的几种Diff方式](http://guochenglai.com/2016/06/08/Mac-%E4%BD%BF%E7%94%A8Beyond-Compare%E7%9A%84%E5%87%A0%E7%A7%8DDiff%E6%96%B9%E5%BC%8F/) ``` Beyond Comapre ``` 虽然比较好用，但是几个也比较贵。本文将介绍两种方法，在保证所有功能正常试用的情况下，实现无限期试用。<font color=red>注：本教程只提供学习交流使用，否则请支持官方正版。</font>（本文教程对应的最新的 ``` Beyond Compare ``` 的版本是：4.1.6）
<!--more-->
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;破解的原理是 ：``` Beyond Compare ``` 有30天的试用期，在你使用未注册的软件的时候会首先检查你的本地有没有 ``` registry.dat ``` 文件，如果没有，就会新建一个文件，并将你的使用开始日期以加密的形式存储在这个文件中。如果有这个文件，就会取出其中的日期，然后进行累加，当累加到30天的时候，你的软件就打不开了。
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;阅读上面的原理可以发现 registry.dat文件是破解的核心。并且生成算法有缺陷，如果我每次删除这个文件，那么注册信息就会被清除。所以永远也不会达到30天的期限。所以有如下两种方法可以实现无限期试用。
## 手工方式
Beyond Compare的试用信息存储的文件的路径为：
<code>/Users/$(whoami)/Library/Application Support/Beyond Compare/registry.dat</code> 
``` $(whoami) ```  是一个shell中的命令，表示的是当前用户，如果你不明白可以不用管。

<font color=red>所以对应的方法是，在30天之内打开命令行终端输入以下命令：</font>
<code>rm /Users/$(whoami)/Library/Application Support/Beyond Compare/registry.dat
</code>

## 自动修改启动程序
Beyond Compare的启动文件的路径为：
<code>/Applications/Beyond Compare.app/Contents/MacOS/BCompare</code>
所以我们可以做如下修改：
1 进入软件的安装目录：
<code>cd /Applications/Beyond\ Compare.app/Contents/MacOS/</code>
2 将启动程序重命名：
<code>mv BCompare BCompare.exec </code>
3 新建一个BCompare文件，文件的内容如下：
<code>#!/bin/bash
rm  "/Users/$(whoami)/Library/Application Support/Beyond Compare/registry.dat"
/Applications/Beyond\ Compare.app/Contents/MacOS/BCompare.exec &
</code>
解释如下：
   3.1 在软件启动之前删除使用信息
   3.2 调用真正的启动软件程序，启动我们的软件
4 给新建的文件授权：
<code>chmod 7555 BCompare </code>如果提示没有权限则执行<code>sudo chmod 755 BCompare </code>
5 破解成功，以后就可以无限试用了。

**<font color=red>再次重申：本教程只使用学习交流，如果不是请支持正版</font>**