---
title: java并发编程之10——for/join框架
toc: true
mathjax: true
date: 2016-07-01 19:49:42
categories:
- Java
- Java并发编程
tags:
- Java
- 并发编程 
- AQS
- fork/join
description: 
---
Fork/Join框架是Java7提供的用户执行并行任务的框架，主要的工作是将大任务分割成若干个小任务。然后并行执行子任务，汇总每个子任务的结果，得到最终结果。他的主要优点有如下两个：
- 内部实现了工作窃取算法，当一个线程完成自己的任务之后，会从其他线程的任务队列的末尾，拿到任务去执行。
- 有封装良好的API，用户只需要定义如何划分任务，不需要关心实现细节。
<!--more-->

## 概述

fork/join框架主要有如下两个类：
- ForkJoinTask：Fork/Join任务，它提供了fork()和join()操作机制。在通常情况下我们只需要继承子类。
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. RecursiveAction:用于没有返回结果的任务
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. RecursiveTask:用户有返回结果的任务
- ForkJoinPool: Fork/Join线程池，新添加的任务都提交到线程池，任务分割出的子任务会添加到当前工作线程的双端队列末尾，当前线程从任务队列的头部取任务，其他线程从任务队列的尾部取任务。

一个fork/join的任务的处理流程可以，类比于如下的伪代码：
```java
Result solve(Problem problem) {
	if (problem is small)
		directly solve problem
	else {
		split problem into independent parts
		fork new subtasks to solve each part
		join all subtasks
		compose result from subresults
	}
}
```
向ForkJoinPool提交一个任务主要有三种方法：
- execute() 调用fork方法将异步地将大任务分割成小任务
- invoke() 等待返回结果
- submit() 返回一个Future对象

获取forkjoin任务的状态的方法
- isDone()  如果任务执行完成就返回true
- isCompletedNormally() 如果任务没有发生异常，或者没有被取消就返回true
- isCancelled() 如果任务被取消了就返回true
- isCompletedabnormally() 任务呗取消或者发生异常就返回true

## 一个例子

下面的一个列子是利用ForkJoin计算Fabonacci数列。
<font color=red>注意:这里只是为了演示如何使用ForkJoin框架，下面的计算方法效率其实还是很低，时间复杂度应该为:O(n^2)。因为Fabonacci数据具有典型的：一个问题的最优解包含子问题的最优解，所以可以采用动态规划来达到最高的效率。
</font>
```java
package com.qunar.dzs.datahub.common.forkjoin;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

/**
 * Created by guochenglai on 7/12/16.
 */
public class ForkJoinTest {

    public static void main(String[] args) {

        long beginTime = System.currentTimeMillis();
        FibonacciTask fibonacciTask = new FibonacciTask(30);
        ForkJoinPool forkJoinPool = new ForkJoinPool(); //默认会实例化出处理器个数个线程

        forkJoinPool.invoke(fibonacciTask); //用线程池执行任务，能够自动实现工作窃取算法

        long endTime = System.currentTimeMillis();

        System.out.println("calculate second is : " + (endTime - beginTime) * 1.0 / 1000);
        System.out.println(fibonacciTask.getRawResult());
    }

    static class FibonacciTask extends RecursiveTask<Long> {

        private final long n;

        public FibonacciTask(long n) {
            this.n = n;
        }

        @Override
        protected Long compute() {
            if (n <= 1) {
                return n;
            }

            FibonacciTask f1 = new FibonacciTask(n - 1);//对每一次子任务创建一个Fibonacci对象
            f1.fork(); //调用fork用法并行执行
            FibonacciTask f2 = new FibonacciTask(n - 2);

            return f2.compute() + f1.join(); //继续执行并行第二个子任务，执行成功之后，等待
            //第一个子任务f1.join()的执行结果一起返回

        }
    }
}

```

## Fork/Join框架源码分析
Fork/Join框架的源码分析主要分为两个部分：
- ForkJoinPool源码分析
- ForkJoinTask源码分析

### ForkJoinPool源码分析
#### ForkJoinPool构造函数
首先ForkJoin的构造函数如下：
```java
public ForkJoinPool() {
        this(Math.min(MAX_CAP, Runtime.getRuntime().availableProcessors()),
             defaultForkJoinWorkerThreadFactory, null, false);
    }
```
第一个参数，是线程池的线程的个数，默认情况下就是当前机器的处理就的个数。
第二个参数，是ForkJoinPool创建线程的，线程工厂。
第三个参数，是UncaughtExceptionHandler，作用是当线程发生异常的时候调用，默认情况下线程发生不设置，但是在registerWorker的时候，会设置一个默认的handler。
第四个参数，标识是否不使用 ``` LIFO ```  处理模式。
#### ForkJoin线程工厂
线程工厂用来创建一个ForkJoin专用线程。
```java
static final class DefaultForkJoinWorkerThreadFactory
        implements ForkJoinWorkerThreadFactory {
        public final ForkJoinWorkerThread newThread(ForkJoinPool pool) {
            return new ForkJoinWorkerThread(pool);
        }
    }
```
#### ForkJoinWorkThread
ForkJoinWorkThread是被ForkJoinPool管理的专门用来处理ForkJoinTask的线程
首先看一下ForkJoinWorkThread的两个属性:
```java
final ForkJoinPool pool; //第一个属性用来指向当前线程对应的线程池，他在创建线程的时候立即初始化
final ForkJoinPool.WorkQueue workQueue; //第二个字段用来指向当前线程对应的任务列表
```
ForkJoinWorkThread的构造方法
```java
protected ForkJoinWorkerThread(ForkJoinPool pool) {
        super("aForkJoinWorkerThread");
        this.pool = pool; //指定当前线程对应的线程池
    this.workQueue = pool.registerWorker(this); //创建一个WorkQueue,将其插入到WorkQueue集合的合适的位置，并返回这个WorkQueue
    }
```

```java
final WorkQueue registerWorker(ForkJoinWorkerThread wt) {
        UncaughtExceptionHandler handler;
        wt.setDaemon(true);                           // 这里可以看到所有的工作线程都是后台线程
        if ((handler = ueh) != null)
            wt.setUncaughtExceptionHandler(handler); //为每个工作线程设置一个默认的异常处理Handler
        WorkQueue w = new WorkQueue(this, wt); //创建一个任务队列，指定他所属的线程池和所属的线程
        int i = 0;                                    // assign a pool index
        int mode = config & MODE_MASK;
        int rs = lockRunState();
        try { //将常见的任务队列，放到任务队列的集合中
            WorkQueue[] ws; int n;                    // skip if no array
            if ((ws = workQueues) != null && (n = ws.length) > 0) {
                int s = indexSeed += SEED_INCREMENT;  // unlikely to collide
                int m = n - 1;
                i = ((s << 1) | 1) & m;               // odd-numbered indices
                if (ws[i] != null) {                  // collision
                    int probes = 0;                   // step by approx half n
                    int step = (n <= 4) ? 2 : ((n >>> 1) & EVENMASK) + 2;
                    while (ws[i = (i + step) & m] != null) {
                        if (++probes >= n) {
                            workQueues = ws = Arrays.copyOf(ws, n <<= 1);
                            m = n - 1;
                            probes = 0;
                        }
                    }
                }
                w.hint = s;                           // use as random seed
                w.config = i | mode;
                w.scanState = i;                      // publication fence
                ws[i] = w;
            }
        } finally {
            unlockRunState(rs, rs & ~RSLOCK);
        }
        wt.setName(workerNamePrefix.concat(Integer.toString(i >>> 1)));
        return w;
    }
```
#### ForkJoinPool.invoke
```java
public <T> T invoke(ForkJoinTask<T> task) {
        if (task == null)
            throw new NullPointerException();
        externalPush(task);
        return task.join();
    }
```
```java
public final V join() {
        int s;
        if ((s = doJoin() & DONE_MASK) != NORMAL)
            reportException(s);
        return getRawResult();
    }
```
```java
private int doJoin() {
        int s; Thread t; ForkJoinWorkerThread wt; ForkJoinPool.WorkQueue w;
        return (s = status) < 0 ? s :
            ((t = Thread.currentThread()) instanceof ForkJoinWorkerThread) ?
            (w = (wt = (ForkJoinWorkerThread)t).workQueue).
            tryUnpush(this) && (s = doExec()) < 0 ? s :
            wt.pool.awaitJoin(w, this, 0L) :
            externalAwaitDone();
    }
```
```java
final boolean tryUnpush(ForkJoinTask<?> t) {
            ForkJoinTask<?>[] a; int s;
            if ((a = array) != null && (s = top) != base &&
                U.compareAndSwapObject
                (a, (((a.length - 1) & --s) << ASHIFT) + ABASE, t, null)) {
                U.putOrderedInt(this, QTOP, s);
                return true;
            }
            return false;
        }
```
```java
final int awaitJoin(WorkQueue w, ForkJoinTask<?> task, long deadline) {
        int s = 0;
        if (task != null && w != null) {
            ForkJoinTask<?> prevJoin = w.currentJoin;
            U.putOrderedObject(w, QCURRENTJOIN, task);
            CountedCompleter<?> cc = (task instanceof CountedCompleter) ?
                (CountedCompleter<?>)task : null;
            for (;;) {
                if ((s = task.status) < 0)
                    break;
                if (cc != null)
                    helpComplete(w, cc, 0);
                else if (w.base == w.top || w.tryRemoveAndExec(task))
                    helpStealer(w, task);
                if ((s = task.status) < 0)
                    break;
                long ms, ns;
                if (deadline == 0L)
                    ms = 0L;
                else if ((ns = deadline - System.nanoTime()) <= 0L)
                    break;
                else if ((ms = TimeUnit.NANOSECONDS.toMillis(ns)) <= 0L)
                    ms = 1L;
                if (tryCompensate(w)) {
                    task.internalWait(ms);
                    U.getAndAddLong(this, CTL, AC_UNIT);
                }
            }
            U.putOrderedObject(w, QCURRENTJOIN, prevJoin);
        }
        return s;
    }
```
```java
 private int externalAwaitDone() {
        int s = ((this instanceof CountedCompleter) ? // try helping
                 ForkJoinPool.common.externalHelpComplete(
                     (CountedCompleter<?>)this, 0) :
                 ForkJoinPool.common.tryExternalUnpush(this) ? doExec() : 0);
        if (s >= 0 && (s = status) >= 0) {
            boolean interrupted = false;
            do {
                if (U.compareAndSwapInt(this, STATUS, s, s | SIGNAL)) {
                    synchronized (this) {
                        if (status >= 0) {
                            try {
                                wait(0L);
                            } catch (InterruptedException ie) {
                                interrupted = true;
                            }
                        }
                        else
                            notifyAll();
                    }
                }
            } while ((s = status) >= 0);
            if (interrupted)
                Thread.currentThread().interrupt();
        }
        return s;
    }
```

