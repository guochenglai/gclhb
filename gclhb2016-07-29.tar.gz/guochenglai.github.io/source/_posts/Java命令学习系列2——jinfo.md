---
title: Java命令学习系列2——jinfo详解
toc: true
mathjax: true
date: 2016-07-13 14:50:51
categories:
- Java
- Java命令工具
tags:
- Java
- jinfo
description: 
---

本话题的第一篇介绍了如何使用 <code>jps</code>命令，找到我们需要的Java进程。本文是承接上文的内容在找到我们需要的Java进程之后，如何使用<code>jinfo</code>查看该进程的详细信息。

## jinfo作用
<code>jinfo(java configuration information)</code>主要用来查看指定的Java进程的详细配置信息

## jinfo使用方法详解
**可以使用<code>jinfo --help </code>或者使用<code>jinfo -h</code>来查看jinfo所支持的所有选项，如下所示：**
![](http://7xutce.com1.z0.glb.clouddn.com/146960334470965.jpg?imageView2/0/format/jpg)
### jinfo
**不带任何参数的<code>jinfo</cdeo>命令会打印出当前Java进程的详细配置信息包含系统参数信息以及用户参数信息**
![](http://7xutce.com1.z0.glb.clouddn.com/146960405862279.jpg?imageView2/0/format/jpg)
输出的详细信息以及解释如下：
```
Attaching to process ID 12010, please wait...
Debugger attached successfully.
Server compiler detected.
JVM version is 24.45-b08
Java System Properties:

java.runtime.name = Java(TM) SE Runtime Environment
sun.rmi.transport.tcp.responseTimeout = 3000  ##tcp链接的默认超时时间
java.vm.version = 24.45-b08 #jvm的小版本号
sun.boot.library.path = /home/q/java/jdk1.7.0_45/jre/lib/amd64 
qunar.logs = /home/q/www/dragon.des.qunar.com/logs #自定义的日志文件位置
shared.loader = 
java.vendor.url = http://java.oracle.com/
java.vm.vendor = Oracle Corporation
path.separator = :
file.encoding.pkg = sun.io 
java.vm.name = Java HotSpot(TM) 64-Bit Server VM ##jvm的名称
java.util.logging.config.file = /home/q/www/dragon.des.qunar.com/conf/logging.properties ##Java日志文件的配置路径
tomcat.util.buf.StringCache.byte.enabled = true
sun.os.patch.level = unknown
sun.java.launcher = SUN_STANDARD
user.country = US
user.dir = /home/q/www/dragon.des.qunar.com/logs #自定义的项目的目录
java.vm.specification.name = Java Virtual Machine Specification
java.runtime.version = 1.7.0_45-b18
java.awt.graphicsenv = sun.awt.X11GraphicsEnvironment
os.arch = amd64
java.endorsed.dirs = /home/q/tomcat/endorsed
java.util.Arrays.useLegacyMergeSort = true
line.separator = 

java.io.tmpdir = /home/q/www/dragon.des.qunar.com/temp ##本项目的临时文件的路径
java.vm.specification.vendor = Oracle Corporation
java.util.logging.manager = org.apache.juli.ClassLoaderLogManager
java.naming.factory.url.pkgs = org.apache.naming
os.name = Linux ## 操作系统的名称
qunar.cache = /home/q/www/dragon.des.qunar.com/cache ##自定义的缓存路径
sun.jnu.encoding = UTF-8
java.library.path = /usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib
sun.nio.ch.bugLevel = 
curator-dont-log-connection-problems = false
java.class.version = 51.0 ##jvm主版本号
java.specification.name = Java Platform API Specification
sun.management.compiler = HotSpot 64-Bit Tiered Compilers
os.version = 2.6.32-358.23.2.el6.x86_64
user.home = /home/tomcat
user.timezone = PRC
catalina.useNaming = true
java.awt.printerjob = sun.print.PSPrinterJob
file.encoding = UTF-8 ## 默认文件编码
java.specification.version = 1.7
catalina.home = /home/q/tomcat ##tomcat的文件路径
user.name = tomcat ##该进程的所属的用户
java.class.path = /home/q/tomcat/bin/bootstrap.jar
java.naming.factory.initial = org.apache.naming.java.javaURLContextFactory
package.definition = sun.,java.,org.apache.catalina.,org.apache.coyote.,org.apache.tomcat.,org.apache.jasper.
java.vm.specification.version = 1.7
sun.arch.data.model = 64
sun.java.command = org.apache.catalina.startup.Bootstrap start
java.home = /home/q/java/jdk1.7.0_45/jre
user.language = en
java.specification.vendor = Oracle Corporation
awt.toolkit = sun.awt.X11.XToolkit
java.vm.info = mixed mode
java.version = 1.7.0_45
java.ext.dirs = /home/q/java/jdk1.7.0_45/jre/lib/ext:/usr/java/packages/lib/ext
sun.boot.class.path = /home/q/java/jdk1.7.0_45/jre/lib/resources.jar:/home/q/java/jdk1.7.0_45/jre/lib/rt.jar:/home/q/java/jdk1.7.0_45/jre/lib/sunrsasign.jar:/home/q/java/jdk1.7.0_45/jre/lib/jsse.jar:/home/q/java/jdk1.7.0_45/jre/lib/jce.jar:/home/q/java/jdk1.7.0_45/jre/lib/charsets.jar:/home/q/java/jdk1.7.0_45/jre/lib/jfr.jar:/home/q/java/jdk1.7.0_45/jre/classes
server.loader = 
java.vendor = Oracle Corporation
catalina.base = /home/q/www/dragon.des.qunar.com ##catalina.base路径
file.separator = / ##本操作系统的文件分隔符
java.vendor.url.bug = http://bugreport.sun.com/bugreport/
common.loader = ${catalina.base}/lib,${catalina.base}/lib/*.jar,${catalina.home}/lib,${catalina.home}/lib/*.jar
sun.io.unicode.encoding = UnicodeLittle
sun.font.fontmanager = sun.awt.X11FontManager
sun.cpu.endian = little
package.access = sun.,org.apache.catalina.,org.apache.coyote.,org.apache.tomcat.,org.apache.jasper.,sun.beans.
sun.cpu.isalist = 

##以下是传递给jvm的参数
VM Flags:

-Djava.util.logging.config.file=/home/q/www/dragon.des.qunar.com/conf/logging.properties -Xms4096m -Xmx4096m -XX:NewSize=1024m -XX:PermSize=128m -XX:+DisableExplicitGC -Djava.util.Arrays.useLegacyMergeSort=true -Dqunar.logs=/home/q/www/dragon.des.qunar.com/logs -Dqunar.cache=/home/q/www/dragon.des.qunar.com/cache -verbose:gc -XX:+PrintGCDateStamps -XX:+PrintGCDetails -Xloggc:/home/q/www/dragon.des.qunar.com/logs/gc..log -XX:+UseConcMarkSweepGC -XX:-OmitStackTraceInFastThrow -Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager -Djava.endorsed.dirs=/home/q/tomcat/endorsed -Dcatalina.base=/home/q/www/dragon.des.qunar.com -Dcatalina.home=/home/q/tomcat -Djava.io.tmpdir=/home/q/www/dragon.des.qunar.com/temp


```

### jinfo -sysprops
**查看系统参数信息**
![](http://7xutce.com1.z0.glb.clouddn.com/146960486382422.jpg?imageView2/0/format/jpg)

### jinfo -flags 
**查看jvm参数，指jvm启动的时候，用户配置的参数，一般是gc信息，内存信息等等。**
![](http://7xutce.com1.z0.glb.clouddn.com/146960517197372.jpg?imageView2/0/format/jpg)

### jinfo -flag
**查看指定参数的值**
这个命令在我的电脑上并没有使用成功过，不过我在我同事的电脑上使用成功了。有兴趣的同学可以看看这个是什么原因。下面是我电脑的输出内容：
![](http://7xutce.com1.z0.glb.clouddn.com/146960614341071.jpg?imageView2/0/format/jpg)


