---
title: Java命令学习系列4——jstat详解
toc: true
mathjax: true
date: 2016-07-18 17:42:37
categories:
- Java
- Java命令工具
tags:
- Java
- jstat
description: 
---

<code>jstat(JVM Statistics Monitoring Tool)</code>是Oracle公司提供的用户监控虚拟机各种运行状态信息的命令行工具。相比于<code>jmap -dump(上文介绍过：主要是用来监控堆使用情况)</code>它更进一层，可以显示进程中的类装载，内存，垃圾收集，JIT编译等运行时的数据，从而可以对JVM的运行周期内的各个状态有一个宏观的把握。

## jstat 命令的使用
可以使用<code>jstat -help</code>命令查看jstat所支持的所有的命令组合。
![](http://7xutce.com1.z0.glb.clouddn.com/146967136046585.jpg?imageView2/0/format/jpg)
**几个参数的解释如下：**

```
option      以何种方式展现GC的情况
vmid        Java进程的进程号
interval    显示进行信息的时间间隔
count       显示进程信息的次数
```
<font color=red>例如如下命令的意思是：监控进程29487的堆gc情况,每隔500毫秒打印一次，一共打印10次。</font>
```
sudo jstat -gcutil 29487 500 10
```
执行上述命令返回的详细信息如下：
![](http://7xutce.com1.z0.glb.clouddn.com/146967200949492.jpg?imageView2/0/format/jpg)
### option详解
<font color=red>**option选项代表的意思是：用户希望以何种方式组织jvm的返回结果。从功能上分类主要分为如下三类：**</font>
- 类装载，监控类装载卸载数量，总空间以及类装载耗费的时间。如(-class)
- 垃圾收集，主要是关注Java堆的各个区域的gc情况，不同的选项有不同的侧重点，将在下文详细介绍。如(-gc,-gcutil,-gccause,-gccapacity,-gcnew,-gcold,-gcnewcapacity .....)
- 运行期编译情况，输出JIT编译器编译过的方法耗时信息等。如(-compiler,-printcompilation)

### 类装载
执行：<code>jstat -class 23549</code>得到如下结果：
![](http://7xutce.com1.z0.glb.clouddn.com/146967318853640.jpg?imageView2/0/format/jpg)
详细解释:
- Loaded    装载类的数量
- Bytes     转载了的字节（本示例差不多27M）
- Unloaded  卸载类的数量
- Bytes     卸载类的字节数
- Time      类装载花费的时间

### 垃圾收集
#### jstat -gcutil
![](http://7xutce.com1.z0.glb.clouddn.com/146967200949492.jpg?imageView2/0/format/jpg)
详细解释：
- s0    年轻代的第一个survivor区占用的比例
- s1    年轻代的第二个survivor区占用的比例
- E     年轻代的Eden区域的占用比例
- O     老年代的占用比例
- P     永久代的占用比例
- YGC   young gc 的总次数
- YGCT  young gc 的总时间
- FGC   full gc 的总次数
- FGCT  full gc 的总时间
- GCT   gc的总时间（young gc的总时间 +  full gc 的总时间）

#### jstat -gccapacity
![](http://7xutce.com1.z0.glb.clouddn.com/146967498258817.jpg?imageView2/0/format/jpg)
详细解释：
- NGCMN 年轻代的最大空间
- NGCMX 年轻代的最小空间 
- NGC   年轻代的当前空间
- S0C   年轻代第一个survior区空间
- S1C   年轻代第二个survivor区空间
- EC    年轻代Eden区空间
- OGCMN 老年代的最小空间
- OGCMX 老年代的最大空间
- OGC   老年代的当前空间
- OC    老年代的实际空间
- MCMN  
- MCMX   
- MC    
- CCSMN 
- CCSMX 
- CCSC 
- YGC  年轻代的总GC的次数
- FGC  老年代的总GC的次数

#### jstat -gcnew
![](http://7xutce.com1.z0.glb.clouddn.com/146967596348910.jpg?imageView2/0/format/jpg)
详细解释：
- S0C   年轻代第一个survior区空间
- S1C   年轻代第二个survivor区空间
- S0U   年轻代survivor0已使用空间
- S1U   年轻代survivor1已使用空间
- TT    
- MTT
- DSS
- EC   年轻代Eden区空间
- EU   年轻代Eden区已使用空间
- YGC  年轻代的总GC的次数
- FGC  老年代的总GC的次数

#### jstat -gcnewcapacity
![](http://7xutce.com1.z0.glb.clouddn.com/146967607545638.jpg?imageView2/0/format/jpg)
详细解释：
- NGCMN 年轻代的最大空间
- NGCMX 年轻代的最小空间 
- NGC   年轻代的当前空间
- S0CMX 年轻代第一个survior区最大空间
- S0C   年轻代第一个survior区空间
- S1CMX 年轻代第二个survior区最大空间
- S1C   年轻代第二个survivor区空间
- ECMX  年轻代Eden区最大空间
- EC    年轻代Eden区空间
- YGC   年轻代的总GC的次数
- FGC   老年代的总GC的次数

#### 其他选项
命令选项 | 详细说明
---|---
jstat -gcold  | old代对象的信息
stat -gcoldcapacity | old代对象的信息及其占用量
jstat -gcpermcapacity | perm对象的信息及其占用量

### 运行时编译
#### jstat -compiler
<code>jstat -compiler</code>输出从JVM启动到现在编译过的方法以及耗时信息等：
![](http://7xutce.com1.z0.glb.clouddn.com/146967350832441.jpg?imageView2/0/format/jpg)
详细解释：
- Compiled      JIT编译过的方法个数
- Failed        JIT编译失败的方法个数
- Invalid       JIT编译无效的方法个数
- Time          JIT编译耗时
- FailedType    JIT编译失败的类型
- FailedMethod  JIT编译失败的方法

#### jstat -printcompilation
<code>jstat -printcompilation</code>输出当前JVM的即时编译信息
![](http://7xutce.com1.z0.glb.clouddn.com/146967391379142.jpg?imageView2/0/format/jpg)
详细解释：
- Compiled   JIT已经编译过的方法的个数
- Size       
- Type       
- Method    JIT正在编译的方法