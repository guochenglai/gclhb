---
title: 软件破解过程详解（以Paw软件为例）
toc: true
mathjax: true
date: 2016-06-16 11:07:29
categories:
- Mac常用技巧
- 软件破解
tags: 
- Mac常用技巧
- 软件破解
- Paw破解
description: 我们所使用的收费软件一般有两种形式：1 输入注册吗的软件，2 购买VIP的软件。学习过程序的人员都知道，这些实现的本质都是一些 <code>if ... else </code>的判断。所以这些软件的破解思路都是一样的。本文将以 Paw 软件为例。详细介绍软件的破解过程。<font color=red>仅供学习交流。如果是商业用途请支持正版！！！</font>
---
## 概述
<font color=red>**本文以Mac为例，Linux和Mac基本是一样的。windows系统也有想对应的软件，整体思路也基本是一致的。**</font>

在我们使用的收费软件中一般有两种形式：
- 输入注册码
- 购买VIP

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;学习过程序的人都知道，这些实现的本质都是一些<code>if ... else</code>的判断。所以这两种软件的破解思路是一样的。
**例如输入注册码的程序判断思路：**
```
   if [用户已经注册]
      可以正常使用软件
   ELSE if [试用期不到30天]
      可以正常使用软件
   ELSE
      弹框提示不能使用软件   
```
**同理购买VIP的软件的程序判断思路如下：**
```
    if[是VIP用户]
        享受VIP的待遇
    ELSE
        享受普通用户的待遇
```
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;看到上面的执行过程，可以发现如果我们调换 <code>if ... else ... </code> 的处理过程。其实我们就达到了破解软件的效果。所以我们的破解思路从总体上可以分为以下几步：
```
   1 根据可执行的二进制文件，找到上面的 if ... else ... 的代码的头文件 （这个可以使用class dump工具帮助我们分析）
   2 利用反编译工具找到我们代码处理的机器指令（可以通过 Hopper Disassembler工具实现）
   3 根据我们定位的机器指令，找到指令的二进制地址（可以通过gdb调试工具实现）
   4 修改二进制代码，将相等改为不想等，即eq(74)指令改为nep(75)指令(可以通过Hex Fiend实现)
   5 如果是Mac系统，需要为软件生成签名认证。
```
**完成整个破解过程需要安装以下软件**
- class dump  <font color=red>分析找到我们要修改的类</font>
- Hopper Disassembler <font color=red>定位机器指令</font>
- gdb <font color=red>定位机器指令以及二进制地址</font>
- Hex Fiend <font color=red>修改二进制代码</font>

## 破解过程
<font color=red>列出详细过程以及思路。怎么分析的都不在多说了。主要都是围绕概述的思路进行的。</font>

### class dump 找到类文件
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;可以通过<code>class dump -f </code>查找包含关键字的方法名称。这些关键字一般在弹出的输入注册码的页面上的单词，配合我们的经验所得。常用的关键字有 <code>license</code> 、<code>register</code>、<code>validate</code>、<code>vip</code>、<code>isVIP</code>。。。
我们执行
```
class-dump -f license /Applications/Paw.app/Contents/MacOS/Paw
```
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;执行结果如下：
![](http://7xutce.com1.z0.glb.clouddn.com/paw%2Fclass_dump_liscence.png)
分析可以发现 <code>LMWelcomeViewController</code>这个类是控制弹出注册框的类。我们可以继续执行
```
class-dump -f showWelcome /Applications/Paw.app/Contents/MacOS/Paw
```
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;结果如下：
![](http://7xutce.com1.z0.glb.clouddn.com/paw%2Fclass_dump_show_welcome.png)
看到这个输出，基本可以确定 <code>LMWelcomeViewController</code> 就是我们要找的类。
### Hopper Disassembler 找到机器指令
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;使用 <code>Hopper Disassembler</code> 软件打开 <code>/Applications/Paw.app/Contents/MacOS/Paw</code> 二进制执行程序。如果软件无法直接选择，可以建立一个软连到目标文件。
在 <code>Hopper Disassembler</code> 软件的左上边的lables下面搜索 "showWelcomeWindow"，可以发现五个类，通过分析，我们要找的方法是： <code>LMWelcomeViewController.showWelcomeWindows</code>。所以打开方法，最后页面显示如下：
![](http://7xutce.com1.z0.glb.clouddn.com/paw%2Fhopper_disassemble_show_welcome.png)
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;通过上面的图片可以看到<code>LMWelcomeViewController.showWelcomeWindows</code>的两条指令<code>je</code>、<code>ret</code>。je执行表示判断两条指令是否相等，ret指令表示返回执行。所以可以猜想这段代码的逻辑是：
```
   if (XXX).equals(XXX)
       弹框
   else return；
```
可以通过<code>Hopper Disassembler</code>生成伪代码看看：
![](http://7xutce.com1.z0.glb.clouddn.com/paw%2Fhopper_disassemble_code.png)
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;想法基本正确。至此，我们已经找到了要修改的指令代码的位置。接下来的问题就是计算出指令代码的二进制地址，然后替换二进制地址。
### gdb 计算eq指令的二进制地址
通过上图可以看到 eq 指令的虚拟内存地址是 <code>0x000000010011a7fe</code>现在我们要做的就是利用gdb调试工具根据eq指令的虚拟内存地址，逆向第从内存中找到eq指令的二进制码。首先在命令行执行
```
gdb /Applications/Paw.app/Contents/MacOS/Paw 
```
然后执行
```
x/x 0x000000010011a7fe 
```
得到结果如下：
![](http://7xutce.com1.z0.glb.clouddn.com/paw%2Fgdb_first_byte.png)
从结果可以看到<code>0x55c30174</code>就是二进制指令的十六进制表示。
注意：
Mac使用的Intel处理器，是以小端序存储的，而硬盘上的二进制码是以大端序存储的。所以，这里需要把 "0x55c30174" 改为对应的大端序 "0x7401c355" 然后在二进制文件中搜索。
用<code>Hex Fiend</code>打开<code>/Applications/Paw.app/Contents/MacOS/Paw </code>文件，然后按下<command+f>搜索。如下：
![](http://7xutce.com1.z0.glb.clouddn.com/paw%2Fhex_fiend_search_byte_one.png)
可以发现这个指令出现了很多次，不能直接替换，这也很好理解，代码中判断相等的地方毕竟很多。那么我们可以在对查询一个字节，这样两个字节的重复率应该很低了。所以我们找到eq指令的后继指令ret，继续计算他的二进制地址如下：
![](http://7xutce.com1.z0.glb.clouddn.com/paw%2Fgdb_second_byte.png)
得到 <code>0x894855c3</code> 将其转换为大端序为：<font color=red>0xc3554889</font>可以看到eq指令的后四位和ret指令的前四位完全相同。原因是不同指令的二进制长度不同，而gdb的 x/x 命令读取的指令的长度总是相同。所以这里出现了重叠。最后可以确定我们要找到的指令是<code>0x7401c3554889</code>
然后我们再次打开Hex Fiend 查询 “7401c3554889”发现这次结果只有一个（如果有多个，就在查询一个指令以此类推）。
然后我们执行替换工作：
![](http://7xutce.com1.z0.glb.clouddn.com/paw%2Fhex_fiend_replace.png)
其实我们只是将74(eq)命令改成了75(nep)命令,也就是调换了处理逻辑。如概述所说。
## codesign生成签名
上面过程已经完成了整个破解过程，还是很简单的。但是现在打开软件还是不能使用，会报错。原因是Mac系统对软件进行了MD5校验，如果发现软件二进制被修改了，就会报错退出，这是一种自我的安全保护。但是如果软件是被认证的，则可以执行所以我们需要为软件生成Mac系统的签名。过程如下：
1 打开Mac的KeyChainAccess软件，新建一个认证证书
![](http://7xutce.com1.z0.glb.clouddn.com/paw%2Fkeychain_access_open.png)
2 取一个名字认证类型选择"code sign" 勾选下面的复选框
![](http://7xutce.com1.z0.glb.clouddn.com/paw%2Fkeychain_access_new.png)
3 验证信息中编码是一串数字，要求不能和其他证书的编码重复即可。以及证书的有效期天数
![](http://7xutce.com1.z0.glb.clouddn.com/paw%2Fkeychain_access_new2.png)
4 有一个地方要选择“login”忘记截图了。注意一下是个下拉框
5 剩下的所有信息都走默认，直到完成
6 完成之后如下。注意类型是login，上面没有截图，如果不是删除重来一遍
![](http://7xutce.com1.z0.glb.clouddn.com/paw%2Fkeychain_access_success.png)
7 选择刚刚创建的证书，右击点击"get info "
![](http://7xutce.com1.z0.glb.clouddn.com/paw%2Fkeychain_access_get_info.png)
8 选择 "trust" ---> "always trust"
![](http://7xutce.com1.z0.glb.clouddn.com/paw%2Fkey_chain_access_trust.png)

## 为软件签名

打开命令行执行：
```
sudo codesign -f -s gcl_paw_keychain_access /Applications/Paw.app/Contents/MacOS/Paw 
```
提示如下：
```
/Applications/Paw.app/Contents/MacOS/Paw: replacing existing signature
```
现在软件就可以随便使用啦啦啦啦啦啦啦啦啦啦！！！！

<font color=red>**再次重申:仅供学习交流，请支持正版**</font>




