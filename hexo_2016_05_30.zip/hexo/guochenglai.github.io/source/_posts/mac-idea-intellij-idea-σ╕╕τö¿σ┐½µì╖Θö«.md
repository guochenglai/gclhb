---
title: mac idea(intellij idea)常用快捷键
date: 2016-05-28 20:51:02
categories: Mac常用技巧
tags: 
- Mac
- 快捷键
- idea 快捷键
---
1    切换到左侧列表快捷键  command+1
2    新建文件快捷键 control+enter 或者command+n
3    自动生成代码 例如getter和setter  control+enter 或者command+n
4    查看最近查看的文件 command+e<!-- more -->
5    查看最近修改的文件 command+shift+e
6     当前文件中搜索 command+f
7     当前文件中替换 command+r
8      所有文件中搜索 command+shift+f
9      所有文件中替换 command+shift+r
10    搜索对象的所有引用 alt+f7
11    搜索对象在当前文件中的引用command+f7
12    补全常用代码块（live template） command+j
13    调出对错误提示的处理方法 fn+alt+enter
14    复制上一行到下一行 command+d
15     单行注释 command+/
16     补全当前行（例如行尾的;）shift+command+enter
17     搜索一个类 command+o
18     子类实现父类的方法 controller+i
19     当前代码段上下移 shift+command+上/下
20      当前行上下移 shift+alt+上/下
21     重命名类名 shift+f6
22     查看某个方法被调用的地方 alt+commant+f7
23     查看某个方法定义的地方command+b
24     跳到指定行  command+L
25     debug运行 shift+command+f9
26     直接运行shit+command+f10
27    格式化单个文件alt+command+L
28    调出settings界面 command+,
29    调出本项目的settings界面  command+；
30    关闭当前文件 commnd+w
31    去除多余import的快捷键 alt+control+o
32    竖行横行选择切换 command+shift+8
33    列出一个类的方法列表 command+f12
34  单词的大小写转换 shift+commend+u
